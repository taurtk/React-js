import React from 'react';
import Product from './Product';

export default class ProductList extends React.Component{

render(){

    // let productNodes = this.props.products.map( product => {

    //     return(
    //     <Product key={product.id} name={product.name} quantity={product.quantity} price={product.price}>
    //     </Product>
    // );
    // });
    

    return(
    <>
        <table>
            <thead>
                <tr>
                    <td>Product Name</td>
                    <td>Quantity</td>
                    <td>Price</td>
                </tr>
            </thead>
            <tbody>
                <Product/>
            </tbody>
        </table>
    </>
    );
}

}