import React from 'react';
import { Link } from 'react-router-dom';
import prodContext from './Prodcontext';
export default class Product extends React.Component {
  render() {
    //const path = null;
    return (
    <prodContext.Consumer>
    {
    (value) => (
    <>
    
    {
    value?.map((product) =>{
    return(
      <tr>
      <td><Link to={`/products/${product.name}`}>{product.name}</Link></td>
      <td>{product.quantity}</td>
      <td>Rs.{product.price}</td>
    </tr>
    )
    })
    }
    </>
    )
    }
    </prodContext.Consumer>
    
    );
    
 }
}
 

