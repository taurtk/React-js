import React from "react";
import { Link } from "react-router-dom";
import ProductList from "./ProductList";
import prodContext from './Prodcontext';

class AllProductsPage extends React.Component
{
constructor(props)
{
    super(props);
    this.state={
        error:null,
        isLoaded:false,
        products: []
    }

}

getProducts()
{
    fetch('http://localhost:3000/product')
    .then(response=>response.json())
    .then(
        (result)=>{
            this.setState({
                isLoaded:true,
                products:result
        });
        },
        (error)=>
        {
            this.setState({
                isLoaded:false,
                error
            })
        }
    )
}
componentDidMount()
{
    this.getProducts()

}

render()
{
    return(<>
    <h1>Products</h1>
    <prodContext.Provider value = {this.state.products}>  
      <ProductList/>
    </prodContext.Provider>
  
        <Link to="/addproduct">Add Product</Link>
    </>)
}

}

export default AllProductsPage;