import React from 'react';

const prodContext = React.createContext();
export default prodContext;