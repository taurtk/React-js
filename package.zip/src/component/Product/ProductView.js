import React from "react";
import { Link } from "react-router-dom";
import {useParams} from 'react-router-dom';
const ProductView = () =>
{

    
    const {name} = useParams();

    return(
        <div>
            <h1>Product Details</h1>
            <label>Product Name: &nbsp;</label>
            <label>{name}</label>
            <br/><br/><br/>
            <Link to="/products">Back</Link>
        </div>
    )
}


export default ProductView ;