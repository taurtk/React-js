import axios from "axios";
import {useFormik} from "formik";
import * as Yup from 'yup';

function SendData(b,c,d)
{
  axios.post("http://localhost:3000/product",
    {
    name: b,
    quantity: c,
    price: d
  })
}

const initialValues = 
{
  
  productName: '',
  quantity: '',
  price: ''
}

const onSubmit = values =>
{
  SendData(values.productName,values.quantity,values.price);
  window.location="./products"

}

const validationSchema = Yup.object(
  {
    
    productName: Yup.string()
    .required('ProductName is required'),
    quantity:Yup.number()
    .required('product lenght is required'),
    price: Yup.number()
    .required('price name is required'),
  }
)



function AddProduct()
{
const formik = useFormik({
  initialValues,
  onSubmit,
  validationSchema
})

return(

  <div className="AddProduct">
    <br></br>
    <form onSubmit={formik.handleSubmit}>
      <h3>Add Product</h3>
      

      productName <input type="text" id ="productName" name="productName" onChange={formik.handleChange} value={formik.values.productName}></input>
      {formik.errors.productName?<div>{formik.errors.productName}</div>:null}
      <br></br>
      <br></br>


      quantity <input type="text" id ="quantity" name="quantity" onChange={formik.handleChange} value={formik.values.quantity}></input>
      {formik.errors.quantity?<div>{formik.errors.quantity}</div>:null}
      <br></br>
      <br></br>


      price <input type="text" id ="price" name="price" onChange={formik.handleChange} value={formik.values.price}></input>
      {formik.errors.price?<div>{formik.errors.price}</div>:null}
      <br></br>
      <br></br>
      <button type="submit">Submit</button>
      
    </form>
  </div>
)

}

export default AddProduct;
