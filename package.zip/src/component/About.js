const About = () =>
{
    return(
        <h1> About: This application provides information about the products </h1>
    )
}

export default About;