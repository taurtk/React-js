import logo from './logo.svg';
import './App.css';
import {BrowserRouter as Router , Link, Route, Routes} from 'react-router-dom';
import AboutPage from './component/About';
import AllProductsPage from './component/Product/AllProductList';
import ProductView from './component/Product/ProductView';
import AddProduct from './component/Product/AddProduct';
import React from 'react';


// const ProdContext = React.createContext();
function App() {
  return (
    <div className="App">
      
<Router>
  <Link to="/">About</Link>
  <Link to="/products" style={{marginLeft: 10+'px'}}>Products</Link>
  <Routes>
    <Route path='/' element={<AboutPage/>}></Route>
    <Route path="/products" element={<AllProductsPage/>}></Route>
    <Route path ="/products/:name" element ={<ProductView/>}></Route>
    <Route path ="/addproduct" element={<AddProduct/>}></Route>
  </Routes>
</Router>
    </div>
  );
}

export default App;
